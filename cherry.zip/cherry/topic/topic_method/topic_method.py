# -*- coding: utf-8 -*-


# 计算话题热度, 话题热度=(0.2*浏览量+0.5*回答数+0.3*评论数)*1000
def calculate_hot_value(topic):
    browse_count = topic.browse_count
    answers = topic.answer_set.all()
    answer_count = len(answers)
    comment_count = 0
    for answer in answers:
        comment_count = answer.comment_set.all().count() + comment_count
    hot_value = (0.2*browse_count + 0.5*answer_count + 0.3*comment_count)*1000
    return hot_value