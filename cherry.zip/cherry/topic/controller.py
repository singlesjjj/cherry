# -*- coding: utf-8 -*-

from models import Topic
from method.common_method import res_constructor, nowtime
from topic_method.topic_method import calculate_hot_value
from answer.models import Answer
from users.models import Users, UserFollow, UserToken
import random
import datetime
from django.db.models import Count


def get_hot_topic(user_id):

    topic_list = Topic.objects.filter(is_hot=1).order_by('hot_rank')
    re_data = []
    for topic in topic_list:
        # 计算话题热度,前20不用计算
        hot_value = 0
        if topic.hot_rank > 20:
            hot_value = calculate_hot_value(topic)
        re_data.append({
            'topic_id':topic.topic_id,
            'title':topic.title,
            'preview_img':topic.preview_img,
            'hot':hot_value
        })
    hotspot = {
        'hotspot':re_data
    }
    return res_constructor('200', data=hotspot)

def get_topic_detail(topic_id,user_id):

    try:
        topic = Topic.objects.get(topic_id=topic_id, is_delete=0)
    except:
        return res_constructor('408')

    answer_count = topic.answer_set.all().count()
    follow_count = topic.topic_follower.all().count()

    # 验证用户是否已经关注该话题
    follow = topic.topic_follower.filter(user_id=user_id, topic_id=topic_id)
    if len(follow)==0:
        is_follow = False
    else:
        is_follow = True

    topic_info = {
        'topic_id':topic.topic_id,
        'title':topic.title,
        'description_excerpt':topic.excerpt,
        'description':topic.description,
        'anwser_count':answer_count,
        'follow_count':follow_count,
        'is_followed_topic':is_follow,
        'asker_id':topic.asker.user_id,
        'asker_name':topic.asker.nickname,
        'create_time':topic.create_time,
        'asker_portrait':topic.asker.profile_pic
    }

    re_data = {
        'topic':topic_info
    }

    return res_constructor('200', data=re_data)


def follow_topic(topic_id, user_id):

    try:
        topic = Topic.objects.get(topic_id=int(topic_id), is_delete=0)
    except:
        return res_constructor('408')

    user = Users.objects.get(user_id=user_id)
    topic.topic_follower.add(user)
    return res_constructor('200')


def invite_responder(user_id, topic_id):
    """
    向用户推荐可被邀请回答问题的人
    1.近期有回答相关问题的用户, 5天以内
    2.相关问题有多个回答，3个以上
    3.被多人关注，超过20个
    4.近期活跃用户，随机选取近5天有登录的用户
    """
    try:
        topic = Topic.objects.get(topic_id=int(topic_id), is_delete=0)
    except:
        return res_constructor('408')

    # 获取该名用户已经邀请的人
    user = Users.objects.get(user_id=user_id)
    invite_list = user.inviter.all()

    total = 20
    # 随机各个类型的邀请人数
    first_amount = random.randint(0,total)
    second_amount = random.randint(0, total-first_amount)
    third_amount = random.randint(0, total-second_amount-first_amount)
    fouth_amount = total - first_amount - second_amount - third_amount

    # 获取第一个类型的人，近期有回答相关
    first_group = []
    relate_topic_list = topic.subject.topic_subject.exclude(topic_id=topic_id)
    now = datetime.datetime.now()
    lower_time = now + datetime.timedelta(days=-30)
    for relate_topic in relate_topic_list:
        answer_list = relate_topic.answer_set.filter(create_time__gt=lower_time)
        length = first_amount if len(answer_list) > first_amount else len(answer_list)
        slice = random.sample(answer_list, length)
        for item in slice:
            first_group.append(item.author)

    # 获取第二种类型的人，相关问题有多个回答
    author = Answer.objects.values_list('author').annotate(answer_count = Count('answer_id'))\
        .filter(topic__in=relate_topic_list)
    length = 20 if len(author) > 20 else len(author)
    second_group = random.sample(author, length)

    # 获取第三种类的人, 被多人关注，超过20个
    user_list = UserFollow.objects.values_list('followed_user').annotate(Count('id')).exclude(followed_user_id=user_id)
    length = 20 if len(user_list) > 20 else len(user_list)
    third_group = random.sample(user_list, length)

    # 获取第四种类的人，近5天有登录用户
    lower_time = now + datetime.timedelta(days=-5)
    user_login = UserToken.objects.filter(last_act_time__gt=lower_time).exclude(user_id=user_id)
    length = 20 if len(user_login) > 20 else len(user_login)
    fouth_group = random.sample(user_login, length)

    # 处理各种类型的数据


