# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from method.common_method import nowtime, res_constructor, verify_token

from users.models import Users
import controller
from django.http import JsonResponse


# 获取话题热榜
def get_hot_topic(request):

    token = request.GET.get('token')

    # 验证用户token
    is_valid, user_id, is_visitor = verify_token(token)
    if not is_valid:
        return JsonResponse(res_constructor("407"))

    res = controller.get_hot_topic(user_id)

    return JsonResponse(res)


# 获取话题详情
def get_topic_detail(request):

    token = request.GET.get('token')
    topic_id = request.GET.get('topic_id')

    # 验证用户token
    is_valid, user_id, is_visitor = verify_token(token)
    if not is_valid:
        return JsonResponse(res_constructor("407"))

    res = controller.get_topic_detail(topic_id, user_id)

    return JsonResponse(res)


# 关注话题
def follow_topic(request):

    token = request.GET.get('token')
    topic_id = request.GET.get('topic_id')

    # 验证用户token
    is_valid, user_id, is_visitor = verify_token(token)
    if not is_valid:
        return JsonResponse(res_constructor("407"))
    if is_visitor:
        return JsonResponse(res_constructor('410'))

    res = controller.follow_topic(topic_id, user_id)

    return JsonResponse(res)


# 获取邀请回答用户
def invite_topic_responder(request, topic_id):

    token = request.GET.get('token')
    # 验证用户token
    is_valid, user_id, is_visitor = verify_token(token)
    if not is_valid:
        return JsonResponse(res_constructor("407"))
    if is_visitor:
        return JsonResponse(res_constructor('410'))

    res = controller.invite_responder(user_id, topic_id)
    return JsonResponse(res)