# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

from users.models import Users


# 话题主题表
class Subject(models.Model):

    subject_id = models.AutoField(primary_key=True)
    user = models.ManyToManyField(Users, related_name='user_subject')
    subject_name = models.CharField(max_length=20, null=False)
    is_delete = models.SmallIntegerField(null=False, default=0)


# 创建话题表
class Topic(models.Model):

    topic_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50, null=False)
    # 问题描述的摘要
    excerpt = models.CharField(max_length=100, null=True)
    description = models.CharField(max_length=1000, null=True)
    # 话题发起人数据
    asker = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='asker')
    # 关注问题的用户
    topic_follower = models.ManyToManyField(Users, related_name='topic_follower')
    # 话题主题
    subject = models.ForeignKey(Subject, related_name='topic_subject')
    # 话题预览图
    preview_img = models.CharField(max_length=200, null=True, default='')
    # 浏览量
    browse_count = models.IntegerField(null=False, default=0)
    create_time = models.CharField(max_length=20, null=False)
    # 是否为热门
    is_hot = models.SmallIntegerField(null=False, default=0)
    # 热门排序, 从1到50，数字越小越靠前
    hot_rank = models.SmallIntegerField(null=False, default=0)
    # 是否删除 0未删除，1已删除
    is_delete = models.SmallIntegerField(null=False, default=0)

