# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from users.models import Users
from topic.models import Topic

# Create your models here.

# 回答表
class Answer(models.Model):

    answer_id = models.AutoField(primary_key=True)
    # 作者
    author = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='author')
    # 回答内容摘要
    excerpt = models.CharField(max_length=100, null=False)
    # 回答内容
    content = models.TextField(null=False)
    # 预览图
    preview_img = models.CharField(max_length=500, null=True)
    # 所属话题
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    # 点赞数
    like_count = models.IntegerField(null=False, default=0)
    # 点赞用户
    like_user = models.ManyToManyField(Users, related_name='like_user')
    # 浏览量
    browse_count = models.IntegerField(null=False, default=0)
    # 是否为优秀回答
    is_excellent = models.SmallIntegerField(null=False, default=0)
    # 是否强制推荐
    is_compolsury = models.SmallIntegerField(null=False, default=0)
    create_time = models.DateTimeField(null=False, auto_now_add=True)
    is_delete = models.SmallIntegerField(null=False, default=0)