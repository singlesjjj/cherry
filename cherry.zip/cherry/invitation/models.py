# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from users.models import Users

# Create your models here.

class Invitations(models.Model):

    # 邀请码id，自增
    invitation_id = models.AutoField(primary_key=True)
    # 邀请码, 不为空，不可重复，最长6位
    invitation_code = models.CharField(max_length=6, null=False)
    # 所有者
    owner = models.ForeignKey(Users, on_delete=None)
    # 创建时间
    create_time = models.CharField(max_length=20,null=False)
    # 是否使用，0表示未使用，1表示已使用
    is_used = models.IntegerField(null=False, default=0)
    # 是否删除，0表示未删除，1表示已删除
    is_delete = models.IntegerField(null=False, default=0)