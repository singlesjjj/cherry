# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

# 推荐池
class RecommendPool(models.Model):

    pool_id = models.AutoField(primary_key=True)
    # 用户id、或者是游客id
    user_id = models.IntegerField(null=False, default=0)
    answer_id = models.IntegerField(null=False, default=0)
    reason = models.CharField(null=False, max_length=20)
    is_visitor = models.SmallIntegerField(null=False, default=0)
    # 是否阅读
    is_read = models.SmallIntegerField(null=False, default=0)
    is_delete = models.SmallIntegerField(null=False, default=0)

