# -*- coding: utf-8 -*-

from users.models import Users, UserToken, UserFollow
from models import RecommendPool
from topic.models import Topic, Subject
from answer.models import Answer

from method.common_method import res_constructor, verify_token, nowtime

from recommend_method.recommend_method import get_relation_recomend, check_pushed, handle_recommend_info

import random
import datetime


# 获取用户的推荐，从用户关系以及用户自身兴趣，以及系统优秀回答中选取
def get_recommend(user_id):

    """
    用户关系分为3层，逐层权值降低，用户行为包括点赞以及回答
    第一层：关注关系，即该名用户关注的其他用户
    第二层：朋友圈关系，即该名用户好友(互相关注)的好友
    第三层：同期关系，即该名用户与其他用户为同一批入驻社区，仅对系统邀请用户有此关系

    自身兴趣分为兴趣爱好以及话题主题
    """
    total = 6
    # 随机通过关系获取推荐的数量
    relation_amount = random.randint(3,total)
    # 随机第一层用户推荐数量
    fir_relation_amount = random.randint(2,3)
    sec_relation_amount = relation_amount - fir_relation_amount
    # 随机第一层用户回答的推荐数量
    fir_relation_answer = random.randint(0, fir_relation_amount)
    # 随机第一层用户回答的点赞数量
    fir_relation_like = fir_relation_amount - fir_relation_answer

    # 获取该名用户第一层关系
    fir_relation = UserFollow.objects.filter(user_id=user_id, is_delete=0).order_by('-last_act_time_fu')
    # 获取一层关系的回答以及点赞
    fir_answer_push, fir_like_push = get_relation_recomend(fir_relation, fir_relation_answer, fir_relation_like, user_id)

    # 获取该名用户第二层关系
    fir_relation_ids = [user_id]
    sec_relation_ids = []
    for item in fir_relation:
        fir_relation_ids.append(item.followed_user.user_id)
        if item.is_friend == 1:
            sec_relation_ids.append(item.followed_user.user_id)
    sec_relation = UserFollow.objects.filter\
        (user_id__in=sec_relation_ids, is_delete=0, is_friend=1).exclude(followed_user_id__in=fir_relation_ids).order_by('-last_act_time_fu')
    sec_answer_push, sec_like_push = get_relation_recomend(sec_relation, sec_relation_amount, 0, user_id)

    # 如果第一二层的关系中筛选的数据不够，则启用第三层数据
    user = Users.objects.filter(user_id=user_id)[0]
    gap = relation_amount - (len(fir_answer_push) + len(fir_like_push) + len(sec_answer_push))
    thi_answer_push = []
    if gap > 0 and user.inviter_id == 1:
        # 获取已查询的所有用户id
        searched_user_id = [1]
        for item in fir_relation:
            searched_user_id.append(item.followed_user.user_id)
        for item in sec_relation:
            searched_user_id.append(item.followed_user.user_id)
        third_relation_amount = gap
        # 获取改名用户第三层关系
        register_time = user.register_time
        time_lower = register_time + datetime.timedelta(days=-3)
        time_upper = register_time + datetime.timedelta(days=3)
        thi_relation = Users.objects.filter\
            (register_time__range=[time_lower, time_upper], inviter_id=1).exclude(user_id__in=searched_user_id)
        # 获取第三层关系的话题动态
        for item in thi_relation:
            answer_list = item.author.all().order_by('-create_time')
            for answer in answer_list:
                if not check_pushed(user_id, 0, answer.answer_id):
                    temp_dict = {
                        'answer':answer,
                        'user_id':item.user_id,
                    }
                    thi_answer_push.append(temp_dict)
                    break
            if len(thi_answer_push) == third_relation_amount:
                break

    # 根据用户自身兴趣推荐话题
    # 通过个人兴趣获取推荐数量
    subject_amount = total - relation_amount
    sub_push = []
    for subject in user.user_subject.all():
        for topic in Topic.objects.filter(subject=subject).order_by('-create_time'):
            track = 0
            for answer in Answer.objects.filter(topic=topic).order_by('-like_count')[0:5]:
                if not check_pushed(user_id, 0, answer.answer_id):
                    sub_push.append({'answer':answer, 'subject':subject.subject_name, 'user_id':user_id
                                     })
                    track = 1
                    break
            if track == 1:
                break
        if len(sub_push) == subject_amount:
            break

    # 如果以上筛选出来的数据不够[total]条，那余下的则从系统推荐里出
    system_amount = total - len(sub_push) - len(fir_answer_push) \
                    - len(fir_like_push) - len(sec_answer_push) \
                    - len(thi_answer_push) - len(sub_push)
    sys_push = []
    for answer in Answer.objects.filter(is_excellent=1).order_by('-create_time'):
        if not check_pushed(user_id, 0, answer.answer_id):
            sys_push.append({
                'answer':answer, 'user_id':user_id
            })
        if len(sys_push) == system_amount:
            break

    # 处理已被筛选出来的数据
    recommend = handle_recommend_info(fir_answer_push, fir_like_push, sec_answer_push,
                                      thi_answer_push, sub_push, sys_push)
    return res_constructor('200', data=recommend)


# 获取游客的推荐，从热门以及系统推荐回答以及高赞回答
def get_recommend_visitor(user_id):

    # 选取优秀回答
    vis_push = []
    com_amount = random.randint(0,6)
    answer_list = Answer.objects.filter(is_compolsury=1, is_delete=0).order_by('-create_time')
    for answer in answer_list:
        if not check_pushed(user_id, 1, answer.answer_id):
            vis_push.append({
                'answer':answer
            })
        if len(vis_push) == com_amount:
            break

    if len(vis_push) < com_amount:
        answer_list = Answer.objects.filter(is_excellent=1, is_delete=0).order_by('-create_time')
        for answer in answer_list:
            if not check_pushed(user_id, 1, answer.answer_id):
                vis_push.append({
                    'answer':answer
                })
            if len(vis_push) == com_amount:
                break
    res_list = []
    for item in vis_push:
        author = item['answer'].author
        topic = item['answer'].topic
        answer_info = {
            'author': {
                'user_id': author.user_id,
                'user_name': author.nickname,
                'profile_img_url': author.profile_pic,
                'is_followed': None
            },
            'topic': {
                'topic_id': topic.topic_id,
                'title': topic.title
            },
            'answer': {
                'answer_id': answer.answer_id,
                'excerpt': answer.excerpt,
                'content': answer.content,
                'preview_img': answer.preview_img,
                'like_count': answer.like_count,
                'comment_count': answer.comment_set.filter(is_delete=0).count(),
                'answer_time': answer.create_time
            }
        }
        res_list.append(answer_info)

    return res_constructor('200', data=res_list)