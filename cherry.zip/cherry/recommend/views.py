# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from method.common_method import nowtime, res_constructor, verify_token
from django.http import JsonResponse

import controller

# Create your views here.

# 获取推荐话题
def get_recommend(request):

    token = request.GET.get('token')

    # 验证用户token
    is_valid, user_id, is_visitor = verify_token(token)
    if not is_valid:
        return JsonResponse(res_constructor("407"))

    if is_visitor == 0:
        res = controller.get_recommend(user_id)
    else:
        res = controller.get_recommend_visitor(user_id)

    return JsonResponse(res)