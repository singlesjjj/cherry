# -*- coding: utf-8 -*-

from recommend.models import RecommendPool
from users.models import UserFollow, Users

# 检测是否已经被推送
def check_pushed(user_id, is_visitor, answer_id):

    try:
        RecommendPool.objects.get(user_id=user_id, is_visitor=is_visitor, answer_id=answer_id)
        return True
    except:
        RecommendPool(
            user_id=user_id,
            is_visitor=is_visitor,
            answer_id=answer_id,
            reason=''
        ).save()
        return False


def get_relation_recomend(relation_list, answer_need, like_need, origin_id):

    answer_push = []
    like_push = []
    for item in relation_list:
        if len(answer_push) < answer_need:
            answer_list = item.followed_user.author.all().order_by('-create_time')
            for answer in answer_list:
                if not check_pushed(origin_id, 0, answer.answer_id):
                    temp_dict = {
                        'answer':answer,
                        'user_id':item.user_id,
                        'relate_user':item.followed_user
                    }
                    answer_push.append(temp_dict)
                    break
        if len(like_push) < like_need:
            answers = item.followed_user.like_user.exclude(author_id=origin_id).order_by('-create_time')
            for answer in answers:
                if not check_pushed(origin_id, 0, answer.answer_id):
                    temp_dict = {
                        'answer': answer,
                        'user_id':item.user_id,
                        'relate_user': item.followed_user
                    }
                    like_push.append(temp_dict)
        if len(answer_push) == answer_need and len(like_push) == like_need:
            break

    return answer_push, like_push


def handle_answer_info(answer, is_followed):

    author = answer.author
    topic = answer.topic

    answer_info = {
        'author':{
            'user_id':author.user_id,
            'user_name':author.nickname,
            'profile_img_url':author.profile_pic,
            'is_followed':is_followed
        },
        'topic':{
            'topic_id':topic.topic_id,
            'title':topic.title
        },
        'answer':{
            'answer_id':answer.answer_id,
            'excerpt':answer.excerpt,
            'content':answer.content,
            'preview_img':answer.preview_img,
            'like_count':answer.like_count,
            'comment_count':answer.comment_set.filter(is_delete=0).count(),
            'answer_time':answer.create_time
        }
    }
    return answer_info


def check_followed(user_id, follow_user_id):
    try:
        UserFollow.objects.get(user_id=user_id, followed_user_id=follow_user_id)
        return True
    except:
        return False


def handle_recommend_info(fir_answer_push, fir_like_push, sec_answer_push, thi_answer_push, sub_push, sys_push):
    recommend = []
    for item in fir_answer_push:
        answer_info = handle_answer_info(item['answer'], True)
        answer_info['recommend_reason'] = '推荐自关注用户[%s]的回答'%(item['relate_user'].nickname.encode("UTF-8"))
        recommend.append(answer_info)
    for item in fir_like_push:
        answer_info = handle_answer_info(item['answer'], check_followed(item['user_id'],item['answer'].author_id))
        answer_info['recommend_reason'] = '推荐自关注用户[%s]的赞同'%(item['relate_user'].nickname.encode('utf-8'))
        recommend.append(answer_info)
    for item in sec_answer_push:
        answer_info = handle_answer_info(item['answer'], False)
        answer_info['recommend_reason'] = '推荐自[%s]的好友的回答'%\
                                          (Users.objects.filter(user_id=item['user_id'])[0].nickname.encode('utf-8'))
        recommend.append(answer_info)
    for item in thi_answer_push:
        answer_info = handle_answer_info(item['answer'], False)
        answer_info['recommend_reason'] = '推荐自社区同期'
        recommend.append(answer_info)
    for item in sub_push:
        answer_info = handle_answer_info(item['answer'], check_followed(item['user_id'], item['answer'].author_id))
        answer_info['recommend_reason'] = '推荐自关注主题[%s]'%(item['subject'].encode('utf-8'))
        recommend.append(answer_info)
    for item in sys_push:
        answer_info = handle_answer_info(item['answer'], check_followed(item['user_id'], item['answer'].author_id))
        answer_info['recommend_reason'] = '推荐自精华话题'
        recommend.append(answer_info)

    return recommend
