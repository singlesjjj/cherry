# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

from users.models import Users
from topic.models import Topic


# 邀请回答通知
class InviteNotification(models.Model):

    notification_id = models.AutoField(primary_key=True)
    # 邀请人
    inviter = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='inviter')
    # 受邀者
    invitee = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='invitee')
    # 邀请回答的话题
    topic = models.ForeignKey(Topic)
    # 邀请来源
    origin = models.CharField(max_length=50, null=False)
    # 是否通知
    is_push = models.SmallIntegerField(null=False, default=0)
    # 是否已读
    is_read = models.SmallIntegerField(null=False, default=0)
    # 是否删除
    is_delete = models.SmallIntegerField(null=False, default=0)
    # 创建时间
    create_time = models.DateTimeField(null=False, auto_now_add=True)


