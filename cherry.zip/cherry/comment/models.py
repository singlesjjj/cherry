# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from users.models import Users
from answer.models import Answer

# Create your models here.

# 评论表
class Comment(models.Model):

    comment_id = models.AutoField(primary_key=True)
    # 作者
    author = models.ForeignKey(Users, on_delete=models.CASCADE)
    # 评论内容
    content = models.CharField(max_length=500, null=False)
    # 所属回答
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE)
    # 父级评论
    parent_comment_id = models.IntegerField(null=False, default=0)
    # 回复对象名字
    reply_comment = models.ForeignKey('self', null=True)
    # 创建时间
    create_time = models.CharField(max_length=20, null=False)
    # 是否删除
    is_delete = models.SmallIntegerField(null=False, default=0)