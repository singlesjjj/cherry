# -*- coding: utf-8 -*-

import datetime
import time
from users.models import UserToken

status_code = {
    '200':'操作成功',
    '400':'链接失败',
    '401':'手机已注册',
    '402':'邀请码无效	',
    '403':'验证码错误	',
    '405':'手机格式错误',
    '406':'手机尚未注册',
    '407':'无效token	',
    '408':'话题不存在',
    '409':'手机尚未注册',
    '410':'权限不足',
    '418':'参数错误',
}


def nowtime():
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S")


def res_constructor(status, data=None):
    return {
        'status':status,
        'msg':status_code[status],
        'data':data
    }


def nowtimestamp():
    dateC1 = datetime.datetime.now()
    cur_time = time.mktime(dateC1.timetuple())
    return cur_time


# 验证token，且返回用户id
def verify_token(token):
    try:
        token = UserToken.objects.get(token=token, is_delete=0, is_expire=0)
    except:
        return False, -1, -1
    token.save()
    return True, token.user_id, token.is_visitor