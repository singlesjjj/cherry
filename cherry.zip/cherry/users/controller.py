# -*- coding: utf-8 -*-

import hashlib
import json
import random
import string

import redis
import requests

from invitation.models import Invitations
from models import Users, UserToken, UserProfile, Visitor
from method.common_method import nowtime, res_constructor, nowtimestamp


# 创建一个redis服务
pool = redis.ConnectionPool(host='127.0.0.1')   #实现一个连接池
r = redis.Redis(connection_pool=pool)


def register(user_info):

    '''

    :param user_info:               用户信息
    :param area_code                区号
    :param tele                     电话
    :param invitation               邀请码
    :param verification             验证码
    :return:
    '''

    # 判断手机是否被注册
    exit = Users.objects.filter(tele=user_info['tele'])
    if len(exit)!=0 :
        return res_constructor('401')

    # 判断验证码是否正确
    if r.get(user_info['tele']) != user_info['verification']:
        return res_constructor('403')

    # 判断邀请码是否有效，并获取该邀请码的所有者
    invitation_code = Invitations.objects.filter(invitation_code=user_info['invitation'],is_used=0,is_delete=0)
    if len(invitation_code) == 0:
        return res_constructor('402')
    invitation_code = invitation_code[0]

    # 生成默认昵称
    nickname = '小樱桃' + ''.join(random.sample(string.digits, 5))

    # 将数据插入用户表
    user = Users.objects.create(
        username=user_info['tele'],
        area_code=user_info['area_code'],
        tele=user_info['tele'],
        nickname=nickname,
        invitation_code=user_info['invitation'],
        inviter_id=invitation_code.owner.user_id,
        ip=user_info['ip'],
        register_time=nowtime(),
        last_login_time=nowtime()
    )
    user.save()

    # 创建用户资料
    UserProfile.objects.create(
        user_id=user.user_id,
        nickname=nickname
    ).save()

    # 销毁此条验证码
    r.delete(user_info['tele'])

    # 将邀请码标注为已使用
    invitation_code.is_used = 1
    invitation_code.save()

    # 创建token， token规则：md5(用户id+当前时间)
    t_str = str(user.user_id)+nowtime()
    token = hashlib.md5(t_str.encode('utf-8')).hexdigest()

    UserToken.objects.create(
        user_id=user.user_id,
        token=token
    ).save()

    return res_constructor('200',{'token':token,'user_id':user.user_id})


def send_msg(url, key, secret, tele, area_code):

    # 判断参数是否正确
    if tele == None or area_code == None:
        return res_constructor('418')

    # 生产验证码，并保存在redis中，有效时间10分钟
    verifi_code = random.randint(100000, 999999)
    r.set(tele,verifi_code)
    r.expire(tele, 600)

    # 构造请求头
    Nonce = random.randint(0, 1000)
    cur_time = nowtimestamp()
    checkSum = hashlib.sha1(str(secret) + str(Nonce) + str(cur_time)).hexdigest()
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'AppKey': key,
        'Nonce': str(Nonce),
        'CurTime': str(cur_time),
        'CheckSum': checkSum,
        'charset': 'utf-8'
    }

    # 构造发送数据
    data = {
        'mobile': '+%s-%s' % (area_code, tele),
        'templateid': '9734405',
        'authCode': verifi_code
    }

    re = requests.post(url=url, headers=headers, data=data)
    re = json.loads(re.content)
    if re['code'] != 200:
        data = {
            'msg_code':re['code']
        }
        return res_constructor('400', data)
    else:
        return res_constructor('200')


def login(user_info):

    # 判断参数是否正确
    try:
        tele = user_info['tele']
        verification = user_info['verification']
    except:
        return res_constructor('418')

    # 判断验证码是否正确
    if verification != r.get(tele):
        return res_constructor('403')

    # 判断手机号是否注册
    try:
        user = Users.objects.get(tele=tele)
    except:
        return res_constructor('409')

    # 创建token， token规则：md5(用户id+当前时间)
    t_str = str(user.user_id) + nowtime()
    token = hashlib.md5(t_str.encode('utf-8')).hexdigest()

    user_token = UserToken.objects.get_or_create(user_id=user.user_id)[0]
    user_token.token=token
    user_token.save()

    return res_constructor('200')


def login_status(token):

    try:
        UserToken.objects.get(token=token, is_delete=0, is_expire=0)
    except:
        return res_constructor('407')

    return res_constructor('200')


def regi_visitor(device_id, ip):

    # 将游客信息写入游客表
    visitor = Visitor(
        device_id=device_id,
        ip=ip
    )
    visitor.save()
    # 创建游客token，将设备码进行MD5加密，并加上后缀_visitor
    token = hashlib.md5(device_id.encode('utf-8')).hexdigest()
    token = token+'_visitor'
    try:
        UserToken.objects.get(token=token, is_visitor=1)
    except:
        UserToken.objects.create(token=token, is_visitor=1, user_id=visitor.visitor_id).save()

    return res_constructor('200',{'token':token})
