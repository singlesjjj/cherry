# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import JsonResponse
from cherry.settings import msg_api, msg_appKey, msg_appSecret

import json
import controller

# Create your views here.

# 用户注册
def register(request):

    body = json.loads(request.body)

    # 获取请求ip
    if request.META.get('HTTP_X_FORWARDED_FOR'):
        ip = request.META.get('HTTP_X_FORWARDED_FOR').split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')

    body['ip'] = ip
    res = controller.register(body)

    return JsonResponse(res)


# 手机验证短信获取
def send_verify_msg(request):

    tele = request.GET.get('tele')
    area_code = request.GET.get('area_code')

    res = controller.send_msg(msg_api, msg_appKey, msg_appSecret, tele, area_code)
    return JsonResponse(res)


# 用户登录
def login(request):

    body = json.loads(request.body)
    res = controller.login(body)

    return JsonResponse(res)


# 判断登录状态
def login_status(request):

    token = json.loads(request.body)['token']
    res = controller.login_status(token)
    return JsonResponse(res)


# 游客信息记录
def regi_visitor(request):

    # 获取请求ip
    if request.META.get('HTTP_X_FORWARDED_FOR'):
        ip = request.META.get('HTTP_X_FORWARDED_FOR').split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')

    device_id = json.loads(request.body)['device_id']
    res = controller.regi_visitor(device_id, ip)
    return JsonResponse(res)