# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.utils import timezone

# Create your models here.


class Users(models.Model):

    # 用户id，自增
    user_id = models.AutoField(primary_key=True)
    # 用户名，最长32字符，不可为空，默认为用户手机号，不可重复
    username = models.CharField(max_length=32,null=False)
    # 密码，最长32，可为空
    passwd = models.CharField(max_length=32)
    # 手机区号，最长5字符
    area_code = models.CharField(max_length=5,null=False)
    # 手机号, 最长20字符，不可为空, 不可重复
    tele = models.CharField(max_length=20, null=False)
    # 用户昵称
    nickname = models.CharField(max_length=20, null=False)
    # 用户头像
    profile_pic = models.CharField(max_length=500, null=True)
    # 入驻时使用邀请码
    invitation_code = models.CharField(max_length=6, null=False)
    # 邀请人id
    inviter_id = models.IntegerField(null=True)
    # 贡献值
    contribution = models.IntegerField(null=False, default=0)
    # 账号状态， 0表示正常，1表示禁言，2表示封禁
    status = models.IntegerField(default=0, null=False)
    # 注册时间
    register_time = models.DateTimeField(null=False, auto_now_add=True)
    # 注册ip
    ip = models.CharField(max_length=100, null=False, default='0.0.0.0')
    # 最后一次动作时间，动作包括点赞以及回答
    last_act_time = models.DateTimeField(null=True)
    # 最后登录时间
    last_login_time = models.DateTimeField(null=False, default=timezone.now)
    # 是否删除， 0表示未删除， 1表示删除
    is_delete = models.SmallIntegerField(null=False, default=0)


# 用户个人资料表
class UserProfile(models.Model):

    profile_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(null=False, default=0)
    nickname = models.CharField(max_length=20, null=False)
    profile_pic = models.CharField(max_length=500, null=True)
    signature = models.CharField(max_length=100, null=True)
    age = models.CharField(max_length=10, null=True)
    gender = models.CharField(max_length=2, null=True)
    height = models.CharField(max_length=5, null=True)
    weight = models.CharField(max_length=5, null=True)
    occupation = models.CharField(max_length=20, null=True)
    location = models.CharField(max_length=20, null=True)
    relationship_situation = models.CharField(max_length=20, null=True)
    recognition = models.CharField(max_length=20, null=True)
    expectation = models.CharField(max_length=20, null=True)


# 兴趣列表
class Interest(models.Model):

    interest_id = models.AutoField(primary_key=True)
    interest_name = models.CharField(max_length=20, null=False)
    is_delete = models.SmallIntegerField(null=False, default=0)


# 兴趣用户关系表
class UserInterest(models.Model):

    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(null=False, default=0)
    interest_id = models.IntegerField(null=False, default=0)


# 用户照片墙
class UserPhotoWall(models.Model):

    photo_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(null=False, default=0)
    photo_url = models.CharField(max_length=200, null=False)
    # 照片顺序
    order_num = models.SmallIntegerField(null=False)


# 用户关注表
class UserFollow(models.Model):

    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(null=False, default=0)
    followed_user = models.ForeignKey(Users, on_delete=models.CASCADE)
    create_time = models.DateTimeField(null=False, auto_now_add=True)
    # 关注用户最新动态时间
    last_act_time_fu = models.DateTimeField(null=True)
    # 标记是否为朋友, 0表示不是朋友, 1表示是朋友
    is_friend = models.SmallIntegerField(null=False, default=0)
    is_delete = models.SmallIntegerField(null=False, default=0)


# 创建用户token, token规则：MD5(用户id+时间戳)
class UserToken(models.Model):

    token_id=models.AutoField(primary_key=True)
    # 用户id、或者是游客id
    user_id=models.IntegerField(null=False, default=0)
    token=models.CharField(max_length=50,null=False)
    # 是否过期
    is_expire=models.SmallIntegerField(null=False,default=0)
    # 是否是游客, 0表示不是游客，1表示为游客
    is_visitor=models.SmallIntegerField(null=False,default=0)
    is_delete=models.SmallIntegerField(null=False,default=0)
    # 上次活动时间
    last_act_time = models.DateTimeField(null=False, auto_now=True)


# 游客表
class Visitor(models.Model):

    visitor_id = models.AutoField(primary_key=True)
    device_id = models.CharField(max_length=40, null=False)
    # 注册时间
    register_time = models.DateTimeField(null=False, auto_now_add=True)
    # 注册ip
    ip = models.CharField(max_length=100, null=False, default='0.0.0.0')
    is_delete = models.SmallIntegerField(null=False,default=0)
